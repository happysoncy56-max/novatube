<?php
// NovaTube — PHP 7.4+ / SQLite (aucune base MySQL à créer). Compatible cPanel & LWS.
session_start();
$D = __DIR__.'/data'; @mkdir($D,0755,true); @mkdir(__DIR__.'/uploads',0755,true);
if(!file_exists("$D/.htaccess")) file_put_contents("$D/.htaccess","<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
$db = new PDO('sqlite:'.$D.'/nt.sqlite'); $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
$db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name,handle UNIQUE,pass,bio,hue INT,created INT);
CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY,uid INT,title,descr,url,views INT DEFAULT 0,created INT);
CREATE TABLE IF NOT EXISTS likes(uid INT,vid INT,PRIMARY KEY(uid,vid));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,vid INT,uid INT,body,created INT);
CREATE TABLE IF NOT EXISTS subs(uid INT,cid INT,PRIMARY KEY(uid,cid));");
function q($s,$a=[]){global $db;$st=$db->prepare($s);$st->execute($a);return $st;}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function me(){return isset($_SESSION['u'])?q("SELECT * FROM users WHERE id=?",[$_SESSION['u']])->fetch(PDO::FETCH_ASSOC):null;}
function ago($t){$d=time()-$t;if($d<3600)return 'il y a '.max(1,floor($d/60)).' min';if($d<86400)return 'il y a '.floor($d/3600).' h';return 'il y a '.floor($d/86400).' j';}
function av($u,$s=36){return '<span class="av" style="width:'.$s.'px;height:'.$s.'px;font-size:'.($s/2.2).'px;background:linear-gradient(135deg,hsl('.$u['hue'].',90%,55%),hsl('.($u['hue']+60).',90%,45%))">'.e(mb_strtoupper(mb_substr($u['name'],0,1))).'</span>';}

// --- Profils de test (mot de passe : test1234) ---
if(!q("SELECT COUNT(*) FROM users")->fetchColumn()){
 $U=[['Awa Studio','awa','Créatrice vidéo, Lomé 🇹🇬',210],['Koffi Tech','koffi','Tutos tech & IA',20],['Mama Cuisine','mama','Recettes d\'Afrique de l\'Ouest 🍲',140],['Kwame Sport','kwame','Football & fitness ⚽',330]];
 foreach($U as $u) q("INSERT INTO users(name,handle,pass,bio,hue,created) VALUES(?,?,?,?,?,?)",[$u[0],$u[1],password_hash('test1234',PASSWORD_DEFAULT),$u[2],$u[3],time()-86400*30]);
 $B='https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/';
 $V=[[1,'Big Buck Bunny — court métrage animé','Le célèbre court métrage open source.','BigBuckBunny.mp4'],[2,'Elephants Dream : voyage surréaliste','Animation 3D réalisée avec Blender.','ElephantsDream.mp4'],[3,'Bande-annonce : Blazes','Démo de test NovaTube.','ForBiggerBlazes.mp4'],[4,'Escapades : démo vidéo','Vidéo de démonstration.','ForBiggerEscapes.mp4'],[1,'Joyrides — vlog de test','Un vlog pour tester le lecteur.','ForBiggerJoyrides.mp4'],[3,'Meltdowns — spécial cuisine','Test de la page chaîne.','ForBiggerMeltdowns.mp4']];
 foreach($V as $i=>$v) q("INSERT INTO videos(uid,title,descr,url,views,created) VALUES(?,?,?,?,?,?)",[$v[0],$v[1],$v[2],$B.$v[3],rand(120,98000),time()-3600*($i*7+2)]);
 q("INSERT INTO comments(vid,uid,body,created) VALUES(1,2,'Super vidéo, bravo ! 🔥',?)",[time()-600]);
}

// --- Actions ---
if(!isset($_SESSION['t'])) $_SESSION['t']=bin2hex(random_bytes(16));
$a=$_POST['a']??''; $err='';
if($a && !hash_equals($_SESSION['t'],$_POST['t']??'')) die('Jeton invalide');
$u=me();
if($a=='login'){ $r=q("SELECT * FROM users WHERE handle=?",[strtolower(trim($_POST['handle']))])->fetch(PDO::FETCH_ASSOC);
 if($r&&password_verify($_POST['pass'],$r['pass'])){$_SESSION['u']=$r['id'];header('Location: ./');exit;} $err='Identifiants incorrects';$_GET['p']='login';}
if($a=='register'){ $h=strtolower(preg_replace('/[^a-z0-9_]/i','',$_POST['handle']));$n=trim($_POST['name']);
 if(strlen($h)<3||!$n||strlen($_POST['pass'])<6){$err='Nom, identifiant (3+) et mot de passe (6+) requis';}
 elseif(q("SELECT 1 FROM users WHERE handle=?",[$h])->fetch()){$err='Identifiant déjà pris';}
 else{q("INSERT INTO users(name,handle,pass,bio,hue,created) VALUES(?,?,?,?,?,?)",[$n,$h,password_hash($_POST['pass'],PASSWORD_DEFAULT),'',rand(0,360),time()]);$_SESSION['u']=$GLOBALS['db']->lastInsertId();header('Location: ./');exit;}
 $_GET['p']='register';}
if($a=='logout'){session_destroy();header('Location: ./');exit;}
if($a=='upload'&&$u){ $f=$_FILES['video']??null; $ext=strtolower(pathinfo($f['name']??'',PATHINFO_EXTENSION));
 if($f&&$f['error']==0&&in_array($ext,['mp4','webm','mov'])&&trim($_POST['title'])){$n=bin2hex(random_bytes(8)).'.'.$ext;move_uploaded_file($f['tmp_name'],__DIR__."/uploads/$n");
  q("INSERT INTO videos(uid,title,descr,url,created) VALUES(?,?,?,?,?)",[$u['id'],trim($_POST['title']),trim($_POST['descr']),"uploads/$n",time()]);header('Location: ?v='.$db->lastInsertId());exit;}
 $err='Fichier (mp4/webm) et titre requis — vérifiez upload_max_filesize dans cPanel.';$_GET['p']='upload';}
if($a=='comment'&&$u&&trim($_POST['body'])){q("INSERT INTO comments(vid,uid,body,created) VALUES(?,?,?,?)",[$_POST['vid'],$u['id'],trim($_POST['body']),time()]);header('Location: ?v='.(int)$_POST['vid'].'#c');exit;}
if($a=='like'||$a=='sub'){ header('Content-Type: application/json'); if(!$u){echo '{"login":1}';exit;}
 if($a=='like'){$k=[$u['id'],$_POST['id']];$on=q("SELECT 1 FROM likes WHERE uid=? AND vid=?",$k)->fetch();q($on?"DELETE FROM likes WHERE uid=? AND vid=?":"INSERT INTO likes VALUES(?,?)",$k);echo json_encode(['on'=>!$on,'n'=>q("SELECT COUNT(*) FROM likes WHERE vid=?",[$_POST['id']])->fetchColumn()]);}
 else{$k=[$u['id'],$_POST['id']];$on=q("SELECT 1 FROM subs WHERE uid=? AND cid=?",$k)->fetch();q($on?"DELETE FROM subs WHERE uid=? AND cid=?":"INSERT INTO subs VALUES(?,?)",$k);echo json_encode(['on'=>!$on,'n'=>q("SELECT COUNT(*) FROM subs WHERE cid=?",[$_POST['id']])->fetchColumn()]);}
 exit;}

function card($v){return '<a class="card" href="?v='.$v['id'].'"><div class="th"><video muted loop playsinline preload="metadata" src="'.e($v['url']).'#t=2"></video></div><div class="meta">'.av($v).'<div><h3>'.e($v['title']).'</h3><p>'.e($v['name']).'<br>'.number_format($v['views'],0,',',' ').' vues · '.ago($v['created']).'</p></div></div></a>';}
$p=$_GET['p']??''; $T=$_SESSION['t'];
?><!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>NovaTube</title><link rel="icon" href="logo.png">
<style>
:root{--bg:#0b1020;--s:#141a30;--s2:#1d2544;--t:#f2f5ff;--m:#97a0c0;--b:#0a84ff;--r:#ff3b1f;--o:#ff9500}
@media(prefers-color-scheme:light){:root{--bg:#f5f7ff;--s:#fff;--s2:#e9edfb;--t:#0d1530;--m:#5b6585}}
*{box-sizing:border-box;margin:0}body{font-family:system-ui,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--t);padding-top:60px}
a{color:inherit;text-decoration:none}
header{position:fixed;top:0;left:0;right:0;height:60px;background:var(--s);display:flex;align-items:center;gap:12px;padding:0 14px;z-index:20;box-shadow:0 2px 14px #0003}
header .logo{display:flex;align-items:center;gap:8px;font-weight:800;font-size:20px}header .logo img{height:40px}
.logo b{background:linear-gradient(90deg,var(--r),var(--o));-webkit-background-clip:text;color:transparent}
form.s{flex:1;max-width:520px;margin:auto;display:flex}form.s input{flex:1;padding:10px 16px;border-radius:30px 0 0 30px;border:1px solid var(--s2);background:var(--bg);color:var(--t);min-width:0}
form.s button{padding:0 18px;border-radius:0 30px 30px 0;border:0;background:var(--s2);color:var(--t);cursor:pointer}
.btn{display:inline-block;border:0;cursor:pointer;padding:10px 18px;border-radius:30px;background:linear-gradient(90deg,var(--b),#6a5cff);color:#fff;font-weight:600;transition:.2s}.btn:hover{transform:translateY(-2px);box-shadow:0 6px 18px #0a84ff55}
.btn.g{background:var(--s2);color:var(--t)}.btn.on{background:var(--s2);color:var(--t)}
.av{display:inline-flex;align-items:center;justify-content:center;border-radius:50%;color:#fff;font-weight:700;flex:none}
nav.side{position:fixed;top:60px;left:0;bottom:0;width:84px;background:var(--bg);display:flex;flex-direction:column;gap:6px;padding:10px 4px;z-index:10}
nav.side a{display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11px;padding:10px 0;border-radius:12px;transition:.2s}nav.side a:hover{background:var(--s2)}nav.side i{font-style:normal;font-size:22px}
main{margin-left:84px;padding:18px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:22px 16px}
.card{display:block;animation:up .5s both;transition:transform .25s}.card:hover{transform:translateY(-4px)}
.card:nth-child(2){animation-delay:.06s}.card:nth-child(3){animation-delay:.12s}.card:nth-child(4){animation-delay:.18s}.card:nth-child(n+5){animation-delay:.24s}
@keyframes up{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}
.th{aspect-ratio:16/9;border-radius:14px;overflow:hidden;background:var(--s2)}.th video{width:100%;height:100%;object-fit:cover;pointer-events:none;transition:transform .4s}.card:hover video{transform:scale(1.06)}
.meta{display:flex;gap:10px;margin-top:10px}.meta h3{font-size:15px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.meta p{font-size:12.5px;color:var(--m);margin-top:3px}
.chips{display:flex;gap:8px;overflow-x:auto;margin-bottom:18px;padding-bottom:4px}.chips a{padding:8px 14px;border-radius:10px;background:var(--s2);white-space:nowrap;font-size:14px}.chips a.on{background:var(--t);color:var(--bg)}
.watch{display:grid;grid-template-columns:1fr 360px;gap:22px;animation:up .4s}.watch video{width:100%;border-radius:16px;background:#000;max-height:70vh}
.row{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:12px 0}.row .sp{flex:1}
.box{background:var(--s);border-radius:14px;padding:14px;margin:12px 0}
input,textarea{width:100%;padding:12px;border-radius:12px;border:1px solid var(--s2);background:var(--s);color:var(--t);font:inherit;margin:6px 0}
.cm{display:flex;gap:10px;margin:14px 0;animation:up .4s}.cm small{color:var(--m)}
.pop{animation:pop .4s}@keyframes pop{50%{transform:scale(1.3)}}
.hero{height:130px;border-radius:16px;margin-bottom:-45px}
.err{background:#ff3b1f22;color:var(--r);padding:10px;border-radius:10px;margin:8px 0}
.form{max-width:440px;margin:30px auto;background:var(--s);padding:24px;border-radius:18px;animation:up .4s}
.form img{height:70px;display:block;margin:auto}
nav.bot{display:none}
@media(max-width:800px){nav.side{display:none}main{margin:0;padding:12px 12px 80px}.watch{grid-template-columns:1fr}.grid{grid-template-columns:1fr}
 nav.bot{display:flex;position:fixed;bottom:0;left:0;right:0;background:var(--s);justify-content:space-around;padding:8px 0 10px;z-index:20}nav.bot a{font-size:11px;text-align:center}nav.bot i{display:block;font-style:normal;font-size:22px}
 header .logo span{display:none}.th{border-radius:0;margin:0 -12px}}
</style></head><body>
<header><a class="logo" href="./"><img src="logo.png" alt=""><span>Nova<b>Tube</b></span></a>
<form class="s" action="./"><input name="q" placeholder="Rechercher" value="<?=e($_GET['q']??'')?>"><button>🔍</button></form>
<?php if($u): ?><a class="btn g" href="?p=upload">＋ Créer</a><a href="?c=<?=$u['id']?>"><?=av($u,38)?></a>
<?php else: ?><a class="btn" href="?p=login">Connexion</a><?php endif ?></header>
<nav class="side"><a href="./"><i>🏠</i>Accueil</a><a href="?q=&s=hot"><i>🔥</i>Tendances</a><a href="?s=subs"><i>📺</i>Abonnements</a><a href="<?=$u?'?c='.$u['id']:'?p=login'?>"><i>👤</i>Vous</a></nav>
<nav class="bot"><a href="./"><i>🏠</i>Accueil</a><a href="?s=hot"><i>🔥</i>Tendances</a><a href="?p=upload"><i>➕</i>Créer</a><a href="?s=subs"><i>📺</i>Abos</a><a href="<?=$u?'?c='.$u['id']:'?p=login'?>"><i>👤</i>Vous</a></nav>
<main>
<?php
if($p=='login'||$p=='register'): $reg=$p=='register'; ?>
<form class="form" method="post"><img src="logo.png" alt=""><h2 style="text-align:center;margin:10px 0"><?=$reg?'Créer un compte':'Connexion'?></h2>
<?php if($err)echo '<div class="err">'.e($err).'</div>'; ?><input type="hidden" name="t" value="<?=$T?>"><input type="hidden" name="a" value="<?=$reg?'register':'login'?>">
<?php if($reg)echo '<input name="name" placeholder="Nom de la chaîne" required>'; ?><input name="handle" placeholder="Identifiant" required><input type="password" name="pass" placeholder="Mot de passe" required>
<button class="btn" style="width:100%;margin-top:8px"><?=$reg?'S\'inscrire':'Se connecter'?></button>
<p style="text-align:center;margin-top:14px;color:var(--m)"><?=$reg?'<a href="?p=login">J\'ai déjà un compte</a>':'<a href="?p=register">Créer un compte</a><br><small>Test : awa / koffi / mama / kwame — mot de passe test1234</small>'?></p></form>
<?php elseif($p=='upload'): if(!$u){header('Location: ?p=login');exit;} ?>
<form class="form" method="post" enctype="multipart/form-data"><h2>Publier une vidéo</h2><?php if($err)echo '<div class="err">'.e($err).'</div>'; ?>
<input type="hidden" name="t" value="<?=$T?>"><input type="hidden" name="a" value="upload"><input name="title" placeholder="Titre" required><textarea name="descr" rows="3" placeholder="Description"></textarea><input type="file" name="video" accept="video/mp4,video/webm" required><button class="btn" style="margin-top:8px">Publier</button></form>
<?php elseif(isset($_GET['v'])): $v=q("SELECT v.*,u.name,u.hue,u.id cid FROM videos v JOIN users u ON u.id=v.uid WHERE v.id=?",[(int)$_GET['v']])->fetch(PDO::FETCH_ASSOC);
 if(!$v){echo '<p>Vidéo introuvable.</p>';}else{ q("UPDATE videos SET views=views+1 WHERE id=?",[$v['id']]);
 $nl=q("SELECT COUNT(*) FROM likes WHERE vid=?",[$v['id']])->fetchColumn();$il=$u&&q("SELECT 1 FROM likes WHERE uid=? AND vid=?",[$u['id'],$v['id']])->fetch();
 $ns=q("SELECT COUNT(*) FROM subs WHERE cid=?",[$v['cid']])->fetchColumn();$is=$u&&q("SELECT 1 FROM subs WHERE uid=? AND cid=?",[$u['id'],$v['cid']])->fetch();
 $C=q("SELECT c.*,u.name,u.hue FROM comments c JOIN users u ON u.id=c.uid WHERE vid=? ORDER BY c.id DESC",[$v['id']])->fetchAll(PDO::FETCH_ASSOC); ?>
<div class="watch"><div><video src="<?=e($v['url'])?>" controls autoplay playsinline></video><h2 style="margin-top:12px"><?=e($v['title'])?></h2>
<div class="row"><a href="?c=<?=$v['cid']?>"><?=av($v,42)?></a><div><b><?=e($v['name'])?></b><br><small style="color:var(--m)"><span id="ns"><?=$ns?></span> abonnés</small></div>
<button class="btn <?=$is?'on':''?>" id="sub" onclick="tg('sub',<?=$v['cid']?>,this)"><?=$is?'Abonné ✓':'S\'abonner'?></button><span class="sp"></span>
<button class="btn g <?=$il?'on':''?>" onclick="tg('like',<?=$v['id']?>,this)"><span id="hl"><?=$il?'❤️':'🤍'?></span> <span id="nl"><?=$nl?></span></button></div>
<div class="box"><b><?=number_format($v['views']+1,0,',',' ')?> vues · <?=ago($v['created'])?></b><p style="margin-top:6px;white-space:pre-line"><?=e($v['descr'])?></p></div>
<div id="c"><h3><?=count($C)?> commentaires</h3>
<?php if($u): ?><form method="post" class="row"><input type="hidden" name="t" value="<?=$T?>"><input type="hidden" name="a" value="comment"><input type="hidden" name="vid" value="<?=$v['id']?>"><input name="body" placeholder="Ajouter un commentaire…" style="flex:1" required><button class="btn">Envoyer</button></form>
<?php else: echo '<p><a href="?p=login" style="color:var(--b)">Connectez-vous</a> pour commenter.</p>'; endif;
foreach($C as $c) echo '<div class="cm">'.av($c,36).'<div><b>'.e($c['name']).'</b> <small>'.ago($c['created']).'</small><br>'.e($c['body']).'</div></div>'; ?></div></div>
<div><?php foreach(q("SELECT v.*,u.name,u.hue FROM videos v JOIN users u ON u.id=v.uid WHERE v.id!=? ORDER BY RANDOM() LIMIT 6",[$v['id']])->fetchAll(PDO::FETCH_ASSOC) as $r)echo card($r).'<br>'; ?></div></div>
<?php } elseif(isset($_GET['c'])): $c=q("SELECT * FROM users WHERE id=?",[(int)$_GET['c']])->fetch(PDO::FETCH_ASSOC);
 if(!$c){echo 'Chaîne introuvable.';}else{ $ns=q("SELECT COUNT(*) FROM subs WHERE cid=?",[$c['id']])->fetchColumn();$is=$u&&q("SELECT 1 FROM subs WHERE uid=? AND cid=?",[$u['id'],$c['id']])->fetch(); ?>
<div class="hero" style="background:linear-gradient(120deg,hsl(<?=$c['hue']?>,90%,50%),hsl(<?=$c['hue']+80?>,90%,40%))"></div>
<div class="row" style="padding:0 14px"><?=av($c,90)?><div><h2>@<?=e($c['handle'])?> · <?=e($c['name'])?></h2><small style="color:var(--m)"><span id="ns"><?=$ns?></span> abonnés</small><p><?=e($c['bio'])?></p></div><span class="sp"></span>
<?php if($u&&$u['id']==$c['id']): ?><form method="post"><input type="hidden" name="t" value="<?=$T?>"><input type="hidden" name="a" value="logout"><button class="btn g">Déconnexion</button></form>
<?php elseif($c['id']): ?><button class="btn <?=$is?'on':''?>" id="sub" onclick="tg('sub',<?=$c['id']?>,this)"><?=$is?'Abonné ✓':'S\'abonner'?></button><?php endif ?></div>
<div class="grid" style="margin-top:20px"><?php foreach(q("SELECT v.*,u.name,u.hue FROM videos v JOIN users u ON u.id=v.uid WHERE uid=? ORDER BY v.id DESC",[$c['id']])->fetchAll(PDO::FETCH_ASSOC) as $r)echo card($r); ?></div>
<?php } else: $w='1';$P=[];$s=$_GET['s']??''; $qq=trim($_GET['q']??'');
 if($qq){$w='v.title LIKE ?';$P=['%'.$qq.'%'];} if($s=='subs'&&$u){$w='v.uid IN (SELECT cid FROM subs WHERE uid='.(int)$u['id'].')';}
 $o=$s=='hot'?'v.views DESC':'v.id DESC'; $L=q("SELECT v.*,u.name,u.hue FROM videos v JOIN users u ON u.id=v.uid WHERE $w ORDER BY $o",$P)->fetchAll(PDO::FETCH_ASSOC); ?>
<div class="chips"><a class="<?=$s?'':'on'?>" href="./">Tous</a><a class="<?=$s=='hot'?'on':''?>" href="?s=hot">Tendances</a><a class="<?=$s=='subs'?'on':''?>" href="?s=subs">Abonnements</a>
<?php foreach(q("SELECT * FROM users LIMIT 8")->fetchAll(PDO::FETCH_ASSOC) as $x)echo '<a href="?c='.$x['id'].'">'.e($x['name']).'</a>'; ?></div>
<div class="grid"><?php foreach($L as $r)echo card($r); if(!$L)echo '<p style="color:var(--m)">Aucune vidéo.</p>'; ?></div>
<?php endif ?>
</main>
<script>
const T="<?=$T?>";
function tg(a,id,b){fetch('?',{method:'POST',body:new URLSearchParams({a,id,t:T})}).then(r=>r.json()).then(d=>{if(d.login){location='?p=login';return}
 if(a=='like'){nl.textContent=d.n;hl.textContent=d.on?'❤️':'🤍';b.classList.toggle('on',d.on);hl.classList.remove('pop');void hl.offsetWidth;hl.classList.add('pop')}
 else{ns.textContent=d.n;b.textContent=d.on?'Abonné ✓':"S'abonner";b.classList.toggle('on',d.on)}})}
document.querySelectorAll('.card').forEach(c=>{const v=c.querySelector('video');c.onmouseenter=()=>v.play().catch(()=>{});c.onmouseleave=()=>{v.pause()}});
</script></body></html>
